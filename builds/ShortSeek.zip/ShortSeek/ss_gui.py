import tkinter as tk
import tkinter.filedialog as filedialog
from tkinter import ttk
from ss_logic import ShortSeeker

class ShortSeekPrompt(tk.Toplevel):
	def __init__(self, master=None, title=None, prompt=None):
		super().__init__(master, padx=16, pady=4)
		self.title(title)
		self.attributes("-toolwindow", 1)
		self.grab_set()
		if master:
			self.geometry(
				"+{}+{}".format(
					master.winfo_rootx() + 48, 
					master.winfo_rooty() + 48
				)
			)
		self.bind(
			"<Escape>", 
			lambda event:
				self.destroy()
		)

		self.prompt = ttk.Label(
			self, 
			text=prompt
		)
		self.prompt.pack(side="top", pady=2)

		self.entry = ttk.Entry(master=self)
		self.entry.pack(side="top", pady=2)
		self.entry.bind(
			"<Return>", 
			lambda event:
				self.affirm()
		)
		self.entry.focus_set()

		self.ok_button = ttk.Button(
			master=self, 
			text="OK", 
			command=self.affirm
		)
		self.ok_button.pack(side="left", pady=2)

		self.cancel_button = ttk.Button(
			master=self, 
			text="Cancel", 
			command=self.destroy
		)
		self.cancel_button.pack(side="right", pady=4)

		self.response = None

	def affirm(self):
		self.response = self.entry.get()
		self.destroy()

	def respond(self):
		self.wait_window()
		return self.response

class ShortSeekGUI(tk.Frame):
	def __init__(self, master=None, seeker=None):
		super().__init__(master)
		self.master = master
		self.master.title("ShortSeek")
		self.pack(pady=8, expand=1, fill=tk.BOTH)
		if not seeker:
			seeker = ShortSeeker()
		self.longest_result_length = len("Search List")

		self.control_frame = ttk.LabelFrame(
			master=self,
			text="Controls"
		)
		self.control_frame.pack(side="left", padx=(8,4))

		self.case_sensitivity_tracker = tk.BooleanVar()
		self.case_sensitivity_tracker.set(seeker.enable_case_sensitivity)
		self.case_sensitivity_toggle = ttk.Checkbutton(
			master=self.control_frame, 
			text="Case Sensitive",
			variable=self.case_sensitivity_tracker
		)
		self.case_sensitivity_toggle.grid(row=0, column=0, sticky=tk.W, padx=8)

		self.fuzzy_tracker = tk.BooleanVar()
		self.fuzzy_tracker.set(seeker.enable_case_sensitivity)
		self.fuzzy_toggle = ttk.Checkbutton(
			master=self.control_frame, 
			text="Fuzzy Filters",
			variable=self.fuzzy_tracker,
			state="disabled"
		)
		self.fuzzy_toggle.grid(row=1, column=0, sticky=tk.W, padx=8)

		self.single_filter_tracker = tk.BooleanVar()
		self.single_filter_tracker.set(seeker.enable_single_filter)
		self.single_filter_toggle = ttk.Checkbutton(
			master=self.control_frame, 
			text="Single Filter",
			variable=self.single_filter_tracker
		)
		self.single_filter_toggle.grid(row=2, column=0, sticky=tk.W, padx=8)

		self.top_result_tracker = tk.BooleanVar()
		self.top_result_tracker.set(seeker.enable_top_result)
		self.top_result_toggle = ttk.Checkbutton(
			master=self.control_frame, 
			text="Top Result",
			variable=self.top_result_tracker,
			state="disabled"
		)
		self.top_result_toggle.grid(row=3, column=0, sticky=tk.W, padx=8)

		self.generate_button = ttk.Button(
			master=self.control_frame, 
			text="Generate",
			command=self.generate
		)
		self.generate_button.grid(row=4, column=0, pady=6)

		self.data_frame = tk.Frame(
			master=self
		)
		self.data_frame.pack(side="right", padx=(4,8), expand=1, fill=tk.BOTH)

		self.table = ttk.Treeview(
			master=self.data_frame,
			show="headings",
			columns=("Search List", "Filters")
		)
		self.table.pack(side="top", expand=1, fill=tk.BOTH)
		self.table.bind(
			"<Delete>", 
			lambda event:
				self.remove_result()
		)
		self.table.bind(
			"<Control-a>", 
			lambda event:
				self.table.selection_set(self.table.get_children())
		)
		self.table.bind(
			"<Escape>", 
			lambda event:
				self.table.selection_remove(self.table.get_children())
		)
		self.table.heading("Search List", text="Search List")
		self.table.heading("Filters", text="Filters")

		self.add_button = ttk.Button(
			master=self.data_frame,
			text="Add",
			command=self.add_result
		)
		self.add_button.pack(side="left")

		self.remove_button = ttk.Button(
			master=self.data_frame,
			text="Remove",
			command=self.remove_result
		)
		self.remove_button.pack(side="left")

		self.save_button = ttk.Button(
			master=self.data_frame,
			text="Save",
			command=self.save_results
		)
		self.save_button.pack(side="right")

		self.import_button = ttk.Button(
			master=self.data_frame,
			text="Import",
			command=self.import_list
		)
		self.import_button.pack(side="right")

	def generate(self):
		seeker = ShortSeeker()
		seeker.set_case_sensitivity(self.case_sensitivity_tracker.get())
		seeker.set_fuzzy(self.fuzzy_tracker.get())
		seeker.set_single_filter(self.single_filter_tracker.get())
		seeker.set_top_result(self.top_result_tracker.get())
		for child in self.table.get_children():
			seeker.add_result(self.table.item(child)["values"][0])
		result_filters = seeker.generate()
		for child in self.table.get_children():
			print(self.table.item(child)["values"][0])
			filters = sorted(result_filters[self.table.item(child)["values"][0]])
			print(filters)
			if not filters:
				filters = "NONE"
			else:
				filters = str(filters)[1:-1]
			self.table.set(child, "Filters", filters)

	def add_result(self, result=None):
		if not result:
			query = ShortSeekPrompt(
				master=self,
				title="Add to List", 
				prompt="Enter a new search item:"
			)
			result = query.respond()
		if result:
			if len(result) > self.longest_result_length:
				self.longest_result_length = len(result)
			self.table.insert("", "end", values=result.replace(" ", "\ "))

	def remove_result(self):
		for child in self.table.selection():          
			self.table.delete(child)

	def clear_results(self):
		for child in self.table.get_children():
			self.table.delete(child)

	def save_results(self):
		path = tk.filedialog.asksaveasfilename()
		if path:
			try:
				with open(path, "w") as out_file:
					output = ("{:<" + str(self.longest_result_length + 1) + "s}| Filters\n").format("Search List")
					output += "-" * (self.longest_result_length + 10) + "\n"
					for child in self.table.get_children():
						result_pair = self.table.item(child)["values"]
						output += ("{:<" + str(self.longest_result_length + 1) + "s}| {}\n").format(result_pair[0], result_pair[1])
					out_file.write(output)
			except IOError as err:
				print(err)

	def import_list(self):
		path = tk.filedialog.askopenfilename()
		if path:
			self.clear_results()
			try:
				with open(path) as list_file:
					for line in list_file:
						self.add_result(line.rstrip())
			except IOError as err:
				print(err)
				self.clear_results()

if __name__ == "__main__":
	root = tk.Tk()
	gui = ShortSeekGUI(master=root)
	gui.mainloop()
