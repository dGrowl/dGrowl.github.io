from typing import Dict, Set
from collections import Counter

def get_substrings(string: str, size: int) -> Set[str]:
	if size < 1:
		return set()
	return {string[i:i + size] for i in range(len(string) - size + 1)}

class ShortSeeker():
	def __init__(self, search_results: Set[str] = set()) -> None:
		self.search_results: Set[str]      = search_results
		self.enable_case_sensitivity: bool = False
		self.enable_fuzzy: bool            = False
		self.enable_single_filter: bool    = False
		self.enable_top_result: bool       = False

	def generate(self) -> Dict[str, Set[str]]:
		result_filters: Dict[str, Set[str]] = {}
		size: int = 1
		while len(result_filters) < len(self.search_results):
			result_substrings: Dict[str, Set[str]] = {}
			for result in self.search_results:
				if self.enable_case_sensitivity:
					result_substrings[result] = get_substrings(result, size)
				else:
					result_substrings[result] = get_substrings(result.lower(), size)
			substring_counts = Counter(substring for substrings in result_substrings.values() for substring in substrings)
			duplicate_substrings = {substring for substring, count in substring_counts.items() if count > 1}
			for result, substrings in result_substrings.items():
				substrings -= duplicate_substrings
				if result not in result_filters:
					if len(substrings):
						if self.enable_single_filter:
							substrings = {min(substrings)}
						result_filters[result] = substrings
					elif len(result) == size:
						result_filters[result] = set()
			size += 1
		return result_filters

	def reset(self) -> None:
		self.search_results          = set()
		self.enable_case_sensitivity = False
		self.enable_fuzzy            = False
		self.enable_single_filter    = False
		self.enable_top_result       = False

	def add_result(self, result: str) -> None:
		self.search_results.add(result)

	def remove_result(self, result: str) -> None:
		self.search_results.remove(result)

	def set_results(self, results: Set[str]) -> None:
		self.search_results = results

	def set_case_sensitivity(self, value: bool) -> None:
		self.enable_case_sensitivity = value

	def set_fuzzy(self, value: bool) -> None:
		self.enable_fuzzy = value

	def set_single_filter(self, value: bool) -> None:
		self.enable_single_filter = value

	def set_top_result(self, value: bool) -> None:
		self.enable_top_result = value
