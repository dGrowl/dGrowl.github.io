import unittest
from ss_logic import *

class SubstringFunctionTests(unittest.TestCase):
	def test_improper_size(self):
		self.assertEqual(
			get_substrings("mongoose", -1),
			set()
		)
		self.assertEqual(
			get_substrings("impala", 0),
			set()
		)
		self.assertEqual(
			get_substrings("kangaroo", 11),
			set()
		)

	def test_repetition(self):
		self.assertEqual(
			get_substrings("aa", 1),
			{"a"}
		)
		self.assertEqual(
			get_substrings("cccc", 3),
			{"ccc"}
		)
		self.assertEqual(
			get_substrings("bzzzz", 2),
			{
				"bz",
				"zz"
			}
		)
		self.assertEqual(
			get_substrings("deded", 1),
			{
				"d",
				"e"
			}
		)
		self.assertEqual(
			get_substrings("deded", 2),
			{
				"de",
				"ed"
			}
		)
		self.assertEqual(
			get_substrings("pandapanda", 3), 
			{
				"pan", 
				"and", 
				"nda", 
				"dap", 
				"apa"
			}
		)

	def test_typical(self):
		self.assertEqual(
			get_substrings("a", 1),
			{"a"}
		)
		self.assertEqual(
			get_substrings("bz", 1),
			{
				"b", 
				"z"
			}
		)
		self.assertEqual(
			get_substrings("bz", 2),
			{"bz"}
		)
		self.assertEqual(
			get_substrings("panda", 3), 
			{
				"pan", 
				"and", 
				"nda"
			}
		)

class ShortSeekerTests(unittest.TestCase):
	def test_default(self):
		seeker = ShortSeeker()
		self.assertEqual(
			seeker.generate(),
			dict()
		)
		seeker.set_results({"panda"})
		self.assertEqual(
			seeker.generate(),
			{
				"panda": {"p", "a", "n", "d", "a"},
			}
		)
		seeker.set_results({"mongoose", "impala", "kangaroo"})
		self.assertEqual(
			seeker.generate(),
			{
				"mongoose": {"s", "e"},
				"impala":   {"i", "p", "l"},
				"kangaroo": {"k", "r"}
			}
		)
		seeker.set_results({"panda", "Panda"})
		self.assertEqual(
			seeker.generate(),
			{
				"panda": set(),
				"Panda": set(),
			}
		)
		seeker.set_results({"panda", "pandapanda"})
		self.assertEqual(
			seeker.generate(),
			{
				"panda":      set(),
				"pandapanda": {"ap"},
			}
		)
		seeker.set_results({"radio", "radioactivitas", "radioactivus", "radiographema", "radiographia", "radior", "radius", "radix", "adixr"})
		self.assertEqual(
			seeker.generate(),
			{
				"radio":          set(), 
				"radioactivitas": {"vi", "it", "ta", "as"}, 
				"radioactivus":   {"vu"}, 
				"radiographema":  {"e", "m"}, 
				"radiographia":   {"hi", "ia"}, 
				"radior":         {"or"}, 
				"radius":         {"iu"}, 
				"radix":          {"radix"},
				"adixr":          {"xr"}
			}
		)
		seeker.set_results({"cUR", "cura", "cuRATiO", "CUraTor", "curIa", "cuRiosItAS", "curiOSuS"})
		self.assertEqual(
			seeker.generate(),
			{
				"cUR":        set(), 
				"cura":       set(), 
				"cuRATiO":    {"ti"}, 
				"CUraTor":    {"to", "or"}, 
				"curIa":      {"ia"}, 
				"cuRiosItAS": {"si", "it", "ta", "as"}, 
				"curiOSuS":   {"su", "us"}
			}
		)

	def test_case_sensitive(self):
		seeker = ShortSeeker()
		seeker.set_case_sensitivity(True)
		seeker.set_results({"panda", "Panda"})
		self.assertEqual(
			seeker.generate(),
			{
				"panda": {"p"},
				"Panda": {"P"},
			}
		)
		seeker.set_results({"cUR", "cura", "cuRATiO", "CUraTor", "curIa", "cuRiosItAS", "curiOSuS"})
		self.assertEqual(
			seeker.generate(),
			{
				"cUR":        {"cU", "UR"}, 
				"cura":       {"ura"}, 
				"cuRATiO":    {"RA", "AT", "Ti"}, 
				"CUraTor":    {"C"}, 
				"curIa":      {"rI", "Ia"}, 
				"cuRiosItAS": {"s", "t"}, 
				"curiOSuS":   {"ri", "OS", "Su", "uS"}
			}
		)

	def test_single_filter(self):
		seeker = ShortSeeker()
		seeker.set_single_filter(True)
		seeker.set_results({"panda"})
		self.assertEqual(
			seeker.generate(),
			{
				"panda": {"a"},
			}
		)
		seeker.set_results({"mongoose", "impala", "kangaroo"})
		self.assertEqual(
			seeker.generate(),
			{
				"mongoose": {"e"},
				"impala":   {"i"},
				"kangaroo": {"k"}
			}
		)
		seeker.set_results({"panda", "Panda"})
		self.assertEqual(
			seeker.generate(),
			{
				"panda": set(),
				"Panda": set(),
			}
		)
		seeker.set_results({"panda", "pandapanda"})
		self.assertEqual(
			seeker.generate(),
			{
				"panda":      set(),
				"pandapanda": {"ap"},
			}
		)
		seeker.set_results({"radio", "radioactivitas", "radioactivus", "radiographema", "radiographia", "radior", "radius", "radix", "adixr"})
		self.assertEqual(
			seeker.generate(),
			{
				"radio":          set(), 
				"radioactivitas": {"as"}, 
				"radioactivus":   {"vu"}, 
				"radiographema":  {"e"}, 
				"radiographia":   {"hi"}, 
				"radior":         {"or"}, 
				"radius":         {"iu"}, 
				"radix":          {"radix"},
				"adixr":          {"xr"}
			}
		)
		seeker.set_results({"cUR", "cura", "cuRATiO", "CUraTor", "curIa", "cuRiosItAS", "curiOSuS"})
		self.assertEqual(
			seeker.generate(),
			{
				"cUR":        set(), 
				"cura":       set(), 
				"cuRATiO":    {"ti"}, 
				"CUraTor":    {"or"}, 
				"curIa":      {"ia"}, 
				"cuRiosItAS": {"as"}, 
				"curiOSuS":   {"su"}
			}
		)

if __name__ == "__main__":
	unittest.TestCase.maxDiff = None
	unittest.main()
