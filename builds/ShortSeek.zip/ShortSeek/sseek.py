from typing import Dict, List, Set
from argparse import ArgumentParser, Namespace
import os.path
from ss_logic import ShortSeeker

if __name__ == "__main__":
	args_parser: ArgumentParser = ArgumentParser(
		usage="sseek.py [options] [list_path]",
		description="Calculates the shortest sequences necessary to filter the elements of a list as desired."
	)
	args_parser.add_argument("list_path", 
		nargs="?", 
		help="file containing search results to filter"
	)
	args_parser.add_argument("-c", "--case-sensitive", 
		action="store_true", 
		help="filters will be case sensitive"
	)
	args_parser.add_argument("-f", "--fuzzy", 
		action="store_true", 
		help="# generate approximate (fuzzy) filters"
	)
	args_parser.add_argument("-g", "--gui", 
		action="store_true", 
		help="# opens a GUI"
	)
	args_parser.add_argument("-o", "--out", 
		action="store", 
		dest="path", 
		default="",
		help="write the generated filters to a file"
	)
	args_parser.add_argument("-s", "--single", 
		action="store_true", 
		help="only display one filter for each result"
	)
	args_parser.add_argument("-t", "--top", 
		action="store_true", 
		help="# filters may be acceptable if they are dominant"
	)
	args: Namespace = args_parser.parse_args()
	seeker: ShortSeeker = ShortSeeker()	
	seeker.set_case_sensitivity(args.case_sensitive)
	seeker.set_fuzzy(args.fuzzy)
	seeker.set_single_filter(args.single)
	seeker.set_top_result(args.top)
	results: List[str] = []
	longest_result_length: int = len("Search List")
	if args.list_path:
		try:
			with open(args.list_path) as list_file:
				for line in list_file:
					result: str = line.rstrip()
					if len(result) > longest_result_length:
						longest_result_length = len(result)
					seeker.add_result(result)
					results.append(result)
		except IOError as err:
			print(err)
	if results:
		result_filters: Dict[str, Set[str]] = seeker.generate()
		output: str = ("{:<" + str(longest_result_length + 1) + "s}| Filters\n").format("Search List")
		output += "-" * (longest_result_length + 10) + "\n"
		for result in results:
			filters = sorted(result_filters[result])
			if not filters:
				filters = "NONE"
			else:
				filters = str(filters)[1:-1]
			output += ("{:<" + str(longest_result_length + 1) + "s}| {}\n").format(result, filters)
		print(output, end="")
		if args.path:
			confirm_write: bool = True
			if os.path.exists(args.path):
				if input(f"File \"{args.path}\" already exists. Overwrite? (y/n)\n").lower() == 'n':
					confirm_write = False 
			if confirm_write:
				try:
					with open(args.path, "w") as out_file:
						out_file.write(output)
				except IOError as err:
					print(err)
